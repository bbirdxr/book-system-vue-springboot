package com.example.booksys.service.impl;

import com.example.booksys.entity.Book;
import com.example.booksys.entity.User;
import com.example.booksys.mapper.BookMapper;
import com.example.booksys.service.IBookService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author XuDaxia
 * @since 2022-07-31
 */
@Service
public class BookServiceImpl extends ServiceImpl<BookMapper, Book> implements IBookService {

    @Autowired
    private BookMapper bookMapper;

    @Override
    public Integer savebook(Book book) {
        boolean ifhavebook = false;
        List<Book> allbook = bookMapper.findAllBook();
        for (Book onebook:allbook)
        {
            if(onebook.getBookId().equals(book.getBookId()))
            {
                ifhavebook = true;
                break;
            }
        }
        if(ifhavebook)//更新
        {
            return bookMapper.update(book);
        }
        else//添加
        {
            return bookMapper.addbook(book);
        }
    }

    @Override
    public List<Book> findbookbyidnametype(Integer bookId, String bookName, Integer bookType) {
        List<Book> returnbook = null;
        List<Book> allbook = bookMapper.findAllBook();
        for (Book onebook:allbook)
        {
            if(onebook.getBookId().equals(bookId) || onebook.getBookName().equals(bookName) || onebook.getType().equals(bookType))
            {
                returnbook.add(onebook);
            }
        }
        return returnbook;
    }
}

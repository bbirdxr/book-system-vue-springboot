package com.example.booksys.mapper;

import com.example.booksys.entity.Book;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.booksys.entity.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XuDaxia
 * @since 2022-07-31
 */
public interface BookMapper extends BaseMapper<Book> {
    @Select("select * from book")
    List<Book> findAllBook();

    @Insert("insert into book(bookId,bookName,type,author,price,language) values(#{bookId},#{bookName},#{type},#{author},#{price},#{language})")
    Integer addbook(Book book);

    @Update("update book set bookId = #{bookId}, bookName = #{bookName}, type = #{type}, author = #{author}, price = #{price}, language = #{language}")
    Integer update(Book book);

    @Delete("delete from book where bookId = #{bookId}")
    Integer deleteBookByid(Integer bookId);
}

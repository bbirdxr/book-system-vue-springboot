package com.example.booksys.controller;


import com.example.booksys.entity.Book;
import com.example.booksys.mapper.BookMapper;
import com.example.booksys.service.impl.BookServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author XuDaxia
 * @since 2022-07-31
 */
@RestController
@RequestMapping("/bookinfo")
public class BookController {
    @Autowired
    private BookMapper bookMapper;

    @Autowired
    private BookServiceImpl bookService;

    @PostMapping("/save")//传入Book，自动根据是否有该Book来修改或添加
    public Integer savebook(@RequestBody Book book)
    {
        return bookService.savebook(book);
    }

    @DeleteMapping("/delete")//根据ID删除
    public Integer deletebookbyid(@RequestBody Integer bookid)
    {
        return bookMapper.deleteBookByid(bookid);
    }

    @RequestMapping("/search")//未分页（待修改）
    public List<Book> findbookbyidnametype(@RequestBody Integer bookId,@RequestBody String bookName,@RequestBody Integer bookType)
    {
        return  bookService.findbookbyidnametype(bookId,bookName,bookType);
    }
}


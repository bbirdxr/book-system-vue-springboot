package com.example.booksys.service.impl;

import com.example.booksys.entity.User;
import com.example.booksys.mapper.UserMapper;
import com.example.booksys.service.IUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author XuDaxia
 * @since 2022-07-31
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {
    @Autowired
    private UserMapper userMapper;


    @Override
    public Integer saveuser(User user) {
        boolean ifhaveuser = false;
        List<User> alluser = userMapper.findAllUser();
        for (User oneuser:alluser)
        {
            if(oneuser.getID().equals(user.getID()))
            {
                ifhaveuser = true;
                break;
            }
        }
        if(ifhaveuser)//更新
        {
            return userMapper.update(user);
        }
        else//添加
        {
            return userMapper.addUser(user);
        }


    }

    @Override
    public User login(String ID, String password, Integer type) {
        List<User> alluser = userMapper.findAllUser();
        User returnuser = null;
        for (User oneuser:alluser)
        {
            if(oneuser.getID().equals(ID) && oneuser.getPassword().equals(password) && oneuser.getType() == type)
            {
                returnuser = oneuser;
                break;
            }
        }
        return  returnuser;
    }

}

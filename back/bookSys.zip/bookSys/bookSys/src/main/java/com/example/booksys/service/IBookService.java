package com.example.booksys.service;

import com.example.booksys.entity.Book;
import com.baomidou.mybatisplus.extension.service.IService;
import com.example.booksys.entity.User;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XuDaxia
 * @since 2022-07-31
 */
public interface IBookService extends IService<Book> {
    public Integer savebook(Book book);
    public List<Book> findbookbyidnametype(Integer bookId, String bookName, Integer bookType);
}
